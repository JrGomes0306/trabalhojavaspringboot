package com.educacional.educacional;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EducacionalApplicationTests {

	@Test
	void contextLoads() {
	}

}

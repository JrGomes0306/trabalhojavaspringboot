package com.educacional.educacional;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EducacionalApplication {

	public static void main(String[] args) {
		SpringApplication.run(EducacionalApplication.class, args);
	}

}
